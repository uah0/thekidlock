#include <stdio.h>
#include <string.h>
#include "ap_mode.h"
#include "app_config.h"
#include "ble_phone.h"
#include "buzzer.h"
#include "led.h"
#include "lock_control.h"
#include "event_log.h"
#include "web_ui.h"
#include "esp_err.h"
#include "esp_check.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"

static const char *TAG = "main";
static bool s_wifi_initialized;
static bool s_ble_initialized;

static void wifi_ap_event_handler(void *arg, esp_event_base_t event_base,
                                  int32_t event_id, void *event_data)
{
    (void)arg;
    (void)event_data;
    if (event_base != WIFI_EVENT) return;

    if (event_id == WIFI_EVENT_AP_START) {
        ESP_LOGI(TAG, "Wi-Fi AP_START event received");
        event_log_add("Wi-Fi AP_START: радио точки доступа запущено");
    } else if (event_id == WIFI_EVENT_AP_STOP) {
        ESP_LOGI(TAG, "Wi-Fi AP_STOP event received");
        event_log_add("Wi-Fi AP_STOP: радио точки доступа остановлено");
    } else if (event_id == WIFI_EVENT_AP_STACONNECTED) {
        ESP_LOGI(TAG, "Wi-Fi station connected to configuration AP");
        event_log_add("Wi-Fi AP: клиент подключён");
    } else if (event_id == WIFI_EVENT_AP_STADISCONNECTED) {
        ESP_LOGI(TAG, "Wi-Fi station disconnected from configuration AP");
        event_log_add("Wi-Fi AP: клиент отключён");
    }
}

static esp_err_t init_nvs(void)
{
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    return err;
}

static esp_err_t wifi_init(void)
{
    ESP_RETURN_ON_ERROR(esp_netif_init(), TAG, "esp_netif_init");
    ESP_RETURN_ON_ERROR(esp_event_loop_create_default(), TAG, "event loop");
    esp_netif_t *ap_netif = esp_netif_create_default_wifi_ap();
    if (!ap_netif) return ESP_ERR_NO_MEM;
#if APP_WIFI_ONLY_DIAGNOSTIC
    esp_netif_t *sta_netif = esp_netif_create_default_wifi_sta();
    if (!sta_netif) return ESP_ERR_NO_MEM;
#endif

    wifi_init_config_t init_cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_RETURN_ON_ERROR(esp_wifi_init(&init_cfg), TAG, "esp_wifi_init");
    ESP_RETURN_ON_ERROR(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
                                                    wifi_ap_event_handler, NULL),
                        TAG, "register AP event handler");
    s_wifi_initialized = true;
    return ESP_OK;
}

static esp_err_t configuration_start(void)
{
    if (!s_wifi_initialized) return ESP_ERR_INVALID_STATE;
    if (s_ble_initialized) {
        ESP_RETURN_ON_ERROR(ble_phone_set_enabled(false), TAG, "pause BLE");
        vTaskDelay(pdMS_TO_TICKS(250));
    }
    wifi_config_t cfg = {0};
    snprintf((char *)cfg.ap.ssid, sizeof(cfg.ap.ssid), "%s", APP_CONFIG_AP_SSID);
    cfg.ap.ssid_len = strlen(APP_CONFIG_AP_SSID);
    cfg.ap.channel = 1;
    cfg.ap.max_connection = 4;
    cfg.ap.authmode = WIFI_AUTH_OPEN;
    cfg.ap.ssid_hidden = 0;
    cfg.ap.beacon_interval = 100;
    cfg.ap.pmf_cfg.required = false;

#if APP_WIFI_ONLY_DIAGNOSTIC
    ESP_RETURN_ON_ERROR(esp_wifi_set_mode(WIFI_MODE_APSTA), TAG, "set APSTA mode");
#else
    ESP_RETURN_ON_ERROR(esp_wifi_set_mode(WIFI_MODE_AP), TAG, "set AP mode");
#endif
    ESP_RETURN_ON_ERROR(esp_wifi_set_config(WIFI_IF_AP, &cfg), TAG, "set AP config");
    ESP_RETURN_ON_ERROR(esp_wifi_set_protocol(WIFI_IF_AP,
                                              WIFI_PROTOCOL_11B |
                                              WIFI_PROTOCOL_11G |
                                              WIFI_PROTOCOL_11N),
                        TAG, "set AP protocol");
    ESP_RETURN_ON_ERROR(esp_wifi_set_bandwidth(WIFI_IF_AP, WIFI_BW_HT20),
                        TAG, "set AP bandwidth");
    ESP_RETURN_ON_ERROR(esp_wifi_start(), TAG, "start AP");
    ESP_RETURN_ON_ERROR(esp_wifi_set_max_tx_power(78), TAG, "set AP TX power");

    wifi_config_t active_cfg = {0};
    uint8_t primary_channel = 0;
    uint8_t protocol = 0;
    int8_t tx_power = 0;
    wifi_second_chan_t second_channel = WIFI_SECOND_CHAN_NONE;
    ESP_RETURN_ON_ERROR(esp_wifi_get_config(WIFI_IF_AP, &active_cfg),
                        TAG, "read AP config");
    ESP_RETURN_ON_ERROR(esp_wifi_get_channel(&primary_channel, &second_channel),
                        TAG, "read AP channel");
    ESP_RETURN_ON_ERROR(esp_wifi_get_protocol(WIFI_IF_AP, &protocol),
                        TAG, "read AP protocol");
    ESP_RETURN_ON_ERROR(esp_wifi_get_max_tx_power(&tx_power),
                        TAG, "read AP TX power");
    ESP_LOGI(TAG, "AP active: SSID='%.*s', hidden=%u, channel=%u, auth=%u, protocol=0x%02x, tx_power=%d",
             active_cfg.ap.ssid_len, active_cfg.ap.ssid, active_cfg.ap.ssid_hidden,
             primary_channel, active_cfg.ap.authmode, protocol, tx_power);
    event_log_add("Wi-Fi AP active: SSID %.*s, hidden %u, channel %u, power %d",
                  active_cfg.ap.ssid_len, active_cfg.ap.ssid,
                  active_cfg.ap.ssid_hidden, primary_channel, tx_power);
#if APP_WIFI_ONLY_DIAGNOSTIC
    ESP_LOGI(TAG, "Starting blocking 2.4 GHz Wi-Fi scan");
    esp_err_t scan_err = esp_wifi_scan_start(NULL, true);
    if (scan_err == ESP_OK) {
        uint16_t ap_count = 0;
        wifi_ap_record_t records[10];
        ESP_RETURN_ON_ERROR(esp_wifi_scan_get_ap_num(&ap_count), TAG, "get scan count");
        uint16_t record_count = ap_count < 10 ? ap_count : 10;
        ESP_RETURN_ON_ERROR(esp_wifi_scan_get_ap_records(&record_count, records),
                            TAG, "get scan records");
        ESP_LOGI(TAG, "Wi-Fi scan complete: found %u network(s)", ap_count);
        event_log_add("Wi-Fi scan: найдено сетей %u", ap_count);
        for (uint16_t i = 0; i < record_count; i++) {
            ESP_LOGI(TAG, "SCAN[%u]: SSID='%s', RSSI=%d, channel=%u, auth=%u",
                     i, records[i].ssid, records[i].rssi,
                     records[i].primary, records[i].authmode);
        }
    } else {
        ESP_LOGE(TAG, "Wi-Fi scan failed: %s", esp_err_to_name(scan_err));
        event_log_add("Wi-Fi scan error: %s", esp_err_to_name(scan_err));
    }
#endif
    esp_err_t err = web_ui_start();
    if (err != ESP_OK) {
        esp_wifi_stop();
        if (s_ble_initialized) ble_phone_set_enabled(true);
        return err;
    }

    led_set_configuration(true);
    ap_mode_set_configuration(true);
    event_log_add("Режим настройки включён: открытая Wi-Fi AP %s, адрес 192.168.4.1",
                  APP_CONFIG_AP_SSID);
    return ESP_OK;
}

static esp_err_t configuration_stop(void)
{
    esp_err_t web_err = web_ui_stop();
    esp_err_t wifi_err = esp_wifi_stop();
    if (web_err != ESP_OK) return web_err;
    if (wifi_err != ESP_OK) return wifi_err;

    ap_mode_set_configuration(false);
    led_set_configuration(false);
    if (s_ble_initialized) {
        ESP_RETURN_ON_ERROR(ble_phone_set_enabled(true), TAG, "resume BLE");
    }
    event_log_add("Режим настройки выключен; Wi-Fi и Web UI остановлены");
    return ESP_OK;
}

static void mode_button_callback(bool configuration_mode, bool erase_bonds)
{
    if (erase_bonds) {
        esp_err_t err = ble_phone_delete_all_bonds();
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "delete all bonds failed: %s", esp_err_to_name(err));
            event_log_add("GPIO0: ошибка удаления bonds: %s", esp_err_to_name(err));
        } else {
            event_log_add("GPIO0: все bonds удалены длинным нажатием");
        }
        return;
    }

    esp_err_t err = configuration_mode ? configuration_start() : configuration_stop();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "configuration mode switch failed: %s", esp_err_to_name(err));
        event_log_add("GPIO0: ошибка переключения режима настройки: %s",
                      esp_err_to_name(err));
    }
}

void app_main(void)
{
    ESP_ERROR_CHECK(init_nvs());
    event_log_init();
    event_log_add("ESP32-S3 start, firmware %s", APP_VERSION);

    ESP_ERROR_CHECK(app_config_init());
    ESP_ERROR_CHECK(led_init());
    led_set_state(LED_STATE_BOOT);
    ESP_ERROR_CHECK(lock_control_init());
    ESP_ERROR_CHECK(buzzer_init());

    ESP_ERROR_CHECK(wifi_init());
#if APP_WIFI_ONLY_DIAGNOSTIC
    ESP_LOGW(TAG, "WI-FI-ONLY DIAGNOSTIC: Bluetooth is not initialized");
    event_log_add("ДИАГНОСТИКА: запуск SoftAP без инициализации Bluetooth");
    ESP_ERROR_CHECK(configuration_start());
    return;
#endif
    ESP_ERROR_CHECK(ble_phone_init());
    s_ble_initialized = true;
    ESP_ERROR_CHECK(ap_mode_init(mode_button_callback));
    event_log_add("Нормальный режим: BLE включён, Wi-Fi и Web UI выключены");
}

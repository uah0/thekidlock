#pragma once

#include <stdint.h>
#include "esp_err.h"

/* Неблокирующий бипер. GPIO настраивается через Web UI. */

esp_err_t buzzer_init(void);
esp_err_t buzzer_set_gpio(int gpio_num);
int buzzer_get_gpio(void);

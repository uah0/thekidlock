#include "buzzer.h"
#include "app_config.h"

#include <stdbool.h>
#include "driver/gpio.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

static SemaphoreHandle_t s_mutex;
static int s_gpio = APP_BUZZER_DEFAULT_GPIO;

static int level_for(bool on)
{
    return APP_BUZZER_ACTIVE_HIGH ? (on ? 1 : 0) : (on ? 0 : 1);
}

static void buzzer_set(bool on)
{
    if (!s_mutex) return;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    gpio_set_level((gpio_num_t)s_gpio, level_for(on));
    xSemaphoreGive(s_mutex);
}

esp_err_t buzzer_set_gpio(int gpio_num)
{
    if (!GPIO_IS_VALID_OUTPUT_GPIO(gpio_num)) return ESP_ERR_INVALID_ARG;
    if (!s_mutex) return ESP_ERR_INVALID_STATE;

    xSemaphoreTake(s_mutex, portMAX_DELAY);
    gpio_set_level((gpio_num_t)s_gpio, level_for(false));
    gpio_reset_pin((gpio_num_t)s_gpio);

    gpio_config_t io = {
        .pin_bit_mask = 1ULL << gpio_num,
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    esp_err_t err = gpio_config(&io);
    if (err == ESP_OK) {
        s_gpio = gpio_num;
        gpio_set_level((gpio_num_t)s_gpio, level_for(false));
    }
    xSemaphoreGive(s_mutex);
    return err;
}

int buzzer_get_gpio(void)
{
    int gpio_num;
    xSemaphoreTake(s_mutex, portMAX_DELAY);
    gpio_num = s_gpio;
    xSemaphoreGive(s_mutex);
    return gpio_num;
}

esp_err_t buzzer_init(void)
{
    s_mutex = xSemaphoreCreateMutex();
    if (!s_mutex) return ESP_ERR_NO_MEM;

    app_config_t cfg;
    app_config_get(&cfg);
    return buzzer_set_gpio(cfg.buzzer_gpio);
}

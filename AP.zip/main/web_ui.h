#pragma once
#include "esp_err.h"
esp_err_t web_ui_start(void);
esp_err_t web_ui_stop(void);

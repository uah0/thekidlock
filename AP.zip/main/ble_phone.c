#include "ble_phone.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "app_config.h"
#include "buzzer.h"
#include "event_log.h"
#include "lock_control.h"
#include "host/ble_hs.h"
#include "host/ble_store.h"
#include "host/ble_uuid.h"
#include "host/util/util.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "services/gap/ble_svc_gap.h"
#include "services/gatt/ble_svc_gatt.h"
#include "nimble/nimble_port.h"
#include "nimble/nimble_port_freertos.h"

#define BLE_PHONE_NAME "BLE Lock"
#define REGISTRATION_WINDOW_US (60LL * 1000000LL)
#define MAX_BONDED_PHONES 10

void ble_store_config_init(void);

enum {
    CHR_LOCK_INFO = 1,
    CHR_LOCK_COMMAND,
    CHR_LOCK_STATUS,
    CHR_ADMIN_AUTH,
    CHR_ADMIN_CONFIG,
};

/* 6f4f0001-9a7b-4c21-8d32-5e6f708192a3 */
static const ble_uuid128_t s_service_uuid = BLE_UUID128_INIT(
    0xa3, 0x92, 0x81, 0x70, 0x6f, 0x5e, 0x32, 0x8d,
    0x21, 0x4c, 0x7b, 0x9a, 0x01, 0x00, 0x4f, 0x6f);
/* 6f4f0002-9a7b-4c21-8d32-5e6f708192a3 */
static const ble_uuid128_t s_info_uuid = BLE_UUID128_INIT(
    0xa3, 0x92, 0x81, 0x70, 0x6f, 0x5e, 0x32, 0x8d,
    0x21, 0x4c, 0x7b, 0x9a, 0x02, 0x00, 0x4f, 0x6f);
/* 6f4f0003-9a7b-4c21-8d32-5e6f708192a3 */
static const ble_uuid128_t s_command_uuid = BLE_UUID128_INIT(
    0xa3, 0x92, 0x81, 0x70, 0x6f, 0x5e, 0x32, 0x8d,
    0x21, 0x4c, 0x7b, 0x9a, 0x03, 0x00, 0x4f, 0x6f);
/* 6f4f0004-9a7b-4c21-8d32-5e6f708192a3 */
static const ble_uuid128_t s_status_uuid = BLE_UUID128_INIT(
    0xa3, 0x92, 0x81, 0x70, 0x6f, 0x5e, 0x32, 0x8d,
    0x21, 0x4c, 0x7b, 0x9a, 0x04, 0x00, 0x4f, 0x6f);

static uint8_t s_addr_type;
static portMUX_TYPE s_registration_lock = portMUX_INITIALIZER_UNLOCKED;
static int64_t s_registration_deadline_us;
static portMUX_TYPE s_connection_lock = portMUX_INITIALIZER_UNLOCKED;
static uint16_t s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
static bool s_enabled = true;
static int8_t s_last_rssi;
static bool s_rssi_valid;
static bool s_encrypted;
static bool s_bonded;
static uint16_t s_admin_conn = BLE_HS_CONN_HANDLE_NONE;

static esp_err_t ble_phone_start_advertising(void);

void ble_phone_get_status(ble_phone_status_t *out)
{
    if (!out) return;
    portENTER_CRITICAL(&s_connection_lock);
    out->connected = s_conn_handle != BLE_HS_CONN_HANDLE_NONE;
    out->encrypted = s_encrypted;
    out->bonded = s_bonded;
    out->rssi_valid = s_rssi_valid;
    out->rssi = s_last_rssi;
    portEXIT_CRITICAL(&s_connection_lock);
}

static void address_to_string(const ble_addr_t *addr, char out[18])
{
    snprintf(out, 18, "%02X:%02X:%02X:%02X:%02X:%02X",
             addr->val[5], addr->val[4], addr->val[3],
             addr->val[2], addr->val[1], addr->val[0]);
}

size_t ble_phone_get_bonds(ble_phone_bond_t *out, size_t max_bonds)
{
    if (!out || max_bonds == 0) return 0;
    ble_addr_t peers[MAX_BONDED_PHONES];
    int count = 0;
    if (ble_store_util_bonded_peers(peers, &count, MAX_BONDED_PHONES) != 0) return 0;
    size_t n = (size_t)count < max_bonds ? (size_t)count : max_bonds;
    for (size_t i = 0; i < n; i++) {
        address_to_string(&peers[i], out[i].address);
        out[i].address_type = peers[i].type;
    }
    return n;
}

esp_err_t ble_phone_delete_bond(const char *address)
{
    if (!address) return ESP_ERR_INVALID_ARG;
    ble_addr_t peers[MAX_BONDED_PHONES];
    int count = 0;
    if (ble_store_util_bonded_peers(peers, &count, MAX_BONDED_PHONES) != 0) return ESP_FAIL;
    for (int i = 0; i < count; i++) {
        char current[18];
        address_to_string(&peers[i], current);
        if (strcmp(current, address) == 0) {
            int rc = ble_store_util_delete_peer(&peers[i]);
            if (rc == 0) event_log_add("BLE bond %s удалён", address);
            return rc == 0 ? ESP_OK : ESP_FAIL;
        }
    }
    return ESP_ERR_NOT_FOUND;
}

esp_err_t ble_phone_delete_all_bonds(void)
{
    ble_addr_t peers[MAX_BONDED_PHONES];
    int count = 0;
    if (ble_store_util_bonded_peers(peers, &count, MAX_BONDED_PHONES) != 0) return ESP_FAIL;
    for (int i = 0; i < count; i++) {
        if (ble_store_util_delete_peer(&peers[i]) != 0) return ESP_FAIL;
    }
    event_log_add("Все BLE bonds удалены: %d", count);
    return ESP_OK;
}

void ble_phone_allow_registration(void)
{
    portENTER_CRITICAL(&s_registration_lock);
    s_registration_deadline_us = esp_timer_get_time() + REGISTRATION_WINDOW_US;
    portEXIT_CRITICAL(&s_registration_lock);
    event_log_add("BLE registration разрешена на 60 секунд");

    // Only one BLE connection is allowed. Release an existing phone so that a
    // new handset can actually reach the Pairing/Bonding flow during the window.
    uint16_t conn_handle;
    portENTER_CRITICAL(&s_connection_lock);
    conn_handle = s_conn_handle;
    portEXIT_CRITICAL(&s_connection_lock);
    if (conn_handle != BLE_HS_CONN_HANDLE_NONE) {
        event_log_add("BLE registration: текущее соединение отключается");
        ble_gap_terminate(conn_handle, BLE_ERR_REM_USER_CONN_TERM);
    } else {
        ble_phone_start_advertising();
    }
}

void ble_phone_get_registration(bool *allowed, uint32_t *remaining_seconds)
{
    int64_t deadline;
    portENTER_CRITICAL(&s_registration_lock);
    deadline = s_registration_deadline_us;
    portEXIT_CRITICAL(&s_registration_lock);

    int64_t remaining_us = deadline - esp_timer_get_time();
    bool active = remaining_us > 0;
    if (allowed) *allowed = active;
    if (remaining_seconds) {
        *remaining_seconds = active ? (uint32_t)((remaining_us + 999999) / 1000000) : 0;
    }
}

static bool peer_has_bond(uint16_t conn_handle, int *bond_count)
{
    ble_addr_t peers[MAX_BONDED_PHONES];
    int count = 0;
    int rc = ble_store_util_bonded_peers(peers, &count, MAX_BONDED_PHONES);
    if (bond_count) *bond_count = rc == 0 ? count : 0;
    if (rc != 0) return false;

    struct ble_gap_conn_desc desc;
    if (ble_gap_conn_find(conn_handle, &desc) != 0) return false;
    for (int i = 0; i < count; i++) {
        if (peers[i].type == desc.peer_id_addr.type &&
            memcmp(peers[i].val, desc.peer_id_addr.val, sizeof(peers[i].val)) == 0) {
            return true;
        }
    }
    return false;
}

static int append_value(struct os_mbuf *om, const void *value, size_t len)
{
    return os_mbuf_append(om, value, len) == 0 ? 0 : BLE_ATT_ERR_INSUFFICIENT_RES;
}

static int gatt_access(uint16_t conn_handle, uint16_t attr_handle,
                       struct ble_gatt_access_ctxt *ctxt, void *arg)
{
    (void)attr_handle;
    intptr_t characteristic = (intptr_t)arg;

    if (ctxt->op == BLE_GATT_ACCESS_OP_READ_CHR && characteristic == CHR_LOCK_INFO) {
        static const char prefix[] = "BLE Lock ";
        int rc = append_value(ctxt->om, prefix, sizeof(prefix) - 1);
        return rc == 0 ? append_value(ctxt->om, APP_VERSION, strlen(APP_VERSION)) : rc;
    }

    if (ctxt->op == BLE_GATT_ACCESS_OP_READ_CHR && characteristic == CHR_LOCK_STATUS) {
        const char *status = lock_control_is_open() ? "OPEN" : "LOCKED";
        return append_value(ctxt->om, status, strlen(status));
    }

    if (ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR && characteristic == CHR_LOCK_COMMAND) {
        uint16_t len = OS_MBUF_PKTLEN(ctxt->om);
        char command[8] = {0};
        if (len >= sizeof(command) || ble_hs_mbuf_to_flat(ctxt->om, command,
                                                          sizeof(command) - 1, NULL) != 0) {
            return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
        }
        if (len == 4 && memcmp(command, "OPEN", 4) == 0) {
            struct ble_gap_conn_desc desc;
            if (ble_gap_conn_find(conn_handle, &desc) != 0 ||
                !desc.sec_state.encrypted || !desc.sec_state.bonded) {
                event_log_add("BLE OPEN отклонён: соединение не encrypted/bonded");
                return BLE_ATT_ERR_INSUFFICIENT_AUTHEN;
            }
            int8_t rssi;
            bool rssi_valid;
            portENTER_CRITICAL(&s_connection_lock);
            rssi = s_last_rssi;
            rssi_valid = s_rssi_valid;
            portEXIT_CRITICAL(&s_connection_lock);
            if (!rssi_valid) {
                event_log_add("BLE OPEN отклонён: RSSI недоступен");
                return BLE_ATT_ERR_UNLIKELY;
            }
            app_config_t cfg;
            app_config_get(&cfg);
            if (rssi < cfg.phone_rssi_threshold) {
                event_log_add("BLE OPEN отклонён: RSSI %d < %d dBm",
                              rssi, cfg.phone_rssi_threshold);
                return BLE_ATT_ERR_WRITE_NOT_PERMITTED;
            }
            esp_err_t err = lock_request_open();
            if (err != ESP_OK) {
                event_log_add("BLE OPEN: очередь автомата недоступна");
                return BLE_ATT_ERR_UNLIKELY;
            }
            event_log_add("BLE OPEN принят: encrypted, bonded, RSSI %d dBm", rssi);
            return 0;
        }
        event_log_add("BLE GATT: неизвестная команда");
        return BLE_ATT_ERR_UNLIKELY;
    }

    if (characteristic == CHR_ADMIN_AUTH || characteristic == CHR_ADMIN_CONFIG) {
        struct ble_gap_conn_desc desc;
        if (ble_gap_conn_find(conn_handle, &desc) != 0 ||
            !desc.sec_state.encrypted || !desc.sec_state.bonded) {
            return BLE_ATT_ERR_INSUFFICIENT_AUTHEN;
        }
        if (characteristic == CHR_ADMIN_AUTH && ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR) {
            uint16_t len = OS_MBUF_PKTLEN(ctxt->om);
            char password[sizeof(APP_ADMIN_PASSWORD)] = {0};
            if (len != strlen(APP_ADMIN_PASSWORD) ||
                ble_hs_mbuf_to_flat(ctxt->om, password, sizeof(password) - 1, NULL) != 0) {
                return BLE_ATT_ERR_INSUFFICIENT_AUTHOR;
            }
            if (memcmp(password, APP_ADMIN_PASSWORD, strlen(APP_ADMIN_PASSWORD)) != 0) {
                event_log_add("BLE admin AUTH отклонён");
                return BLE_ATT_ERR_INSUFFICIENT_AUTHOR;
            }
            s_admin_conn = conn_handle;
            event_log_add("BLE admin AUTH принят");
            return 0;
        }
        if (s_admin_conn != conn_handle) return BLE_ATT_ERR_INSUFFICIENT_AUTHOR;
        if (characteristic == CHR_ADMIN_CONFIG && ctxt->op == BLE_GATT_ACCESS_OP_READ_CHR) {
            app_config_t cfg;
            char value[96];
            app_config_get(&cfg);
            int len = snprintf(value, sizeof(value), "%d,%d,%lu,%lu,%d,%d",
                               cfg.phone_rssi_threshold,
                               cfg.phone_rssi_hold_threshold,
                               (unsigned long)cfg.long_open_ms,
                               (unsigned long)cfg.timer_a_ms,
                               cfg.buzzer_gpio, cfg.lock_open_level ? 1 : 0);
            return append_value(ctxt->om, value, (size_t)len);
        }
        if (characteristic == CHR_ADMIN_CONFIG && ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR) {
            char value[96] = {0};
            int8_t rssi, rssi_hold;
            unsigned long long_open, timer_a;
            int buzzer_gpio, open_level;
            uint16_t len = OS_MBUF_PKTLEN(ctxt->om);
            if (len == 0 || len >= sizeof(value) ||
                ble_hs_mbuf_to_flat(ctxt->om, value, sizeof(value) - 1, NULL) != 0 ||
                sscanf(value, "%hhd,%hhd,%lu,%lu,%d,%d", &rssi, &rssi_hold, &long_open,
                       &timer_a, &buzzer_gpio, &open_level) != 6 ||
                open_level < 0 || open_level > 1) {
                return BLE_ATT_ERR_INVALID_ATTR_VALUE_LEN;
            }
            app_config_t cur_cfg;
            app_config_get(&cur_cfg);
            esp_err_t err = app_config_set_logic(rssi, rssi_hold, (uint32_t)long_open,
                                                  (uint32_t)timer_a, buzzer_gpio,
                                                  cur_cfg.lock_gpio, open_level != 0);
            if (err != ESP_OK) return BLE_ATT_ERR_VALUE_NOT_ALLOWED;
            buzzer_set_gpio(buzzer_gpio);
            lock_control_config_changed();
            event_log_add("BLE admin конфигурация сохранена");
            return 0;
        }
    }

    return BLE_ATT_ERR_UNLIKELY;
}

static const struct ble_gatt_svc_def s_services[] = {
    {
        .type = BLE_GATT_SVC_TYPE_PRIMARY,
        .uuid = &s_service_uuid.u,
        .characteristics = (struct ble_gatt_chr_def[]) {
            {
                .uuid = &s_info_uuid.u,
                .access_cb = gatt_access,
                .arg = (void *)(intptr_t)CHR_LOCK_INFO,
                .flags = BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_READ_ENC,
            },
            {
                .uuid = &s_command_uuid.u,
                .access_cb = gatt_access,
                .arg = (void *)(intptr_t)CHR_LOCK_COMMAND,
                .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_ENC,
            },
            {
                .uuid = &s_status_uuid.u,
                .access_cb = gatt_access,
                .arg = (void *)(intptr_t)CHR_LOCK_STATUS,
                .flags = BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_READ_ENC,
            },
            {
                .uuid = &((ble_uuid128_t)BLE_UUID128_INIT(
                    0xa3,0x92,0x81,0x70,0x6f,0x5e,0x32,0x8d,0x21,0x4c,0x7b,0x9a,0x05,0x00,0x4f,0x6f)).u,
                .access_cb = gatt_access,
                .arg = (void *)(intptr_t)CHR_ADMIN_AUTH,
                .flags = BLE_GATT_CHR_F_WRITE | BLE_GATT_CHR_F_WRITE_ENC,
            },
            {
                .uuid = &((ble_uuid128_t)BLE_UUID128_INIT(
                    0xa3,0x92,0x81,0x70,0x6f,0x5e,0x32,0x8d,0x21,0x4c,0x7b,0x9a,0x06,0x00,0x4f,0x6f)).u,
                .access_cb = gatt_access,
                .arg = (void *)(intptr_t)CHR_ADMIN_CONFIG,
                .flags = BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_WRITE |
                         BLE_GATT_CHR_F_READ_ENC | BLE_GATT_CHR_F_WRITE_ENC,
            },
            {0},
        },
    },
    {0},
};

static int advertising_event(struct ble_gap_event *event, void *arg)
{
    (void)arg;
    switch (event->type) {
        case BLE_GAP_EVENT_CONNECT:
            if (event->connect.status == 0) {
                event_log_add("BLE GATT: телефон подключён");
                portENTER_CRITICAL(&s_connection_lock);
                s_conn_handle = event->connect.conn_handle;
                s_rssi_valid = false;
                s_encrypted = false;
                s_admin_conn = BLE_HS_CONN_HANDLE_NONE;
                s_bonded = false;
                portEXIT_CRITICAL(&s_connection_lock);
                bool registration_allowed;
                ble_phone_get_registration(&registration_allowed, NULL);
                int bond_count = 0;
                bool bonded_peer = peer_has_bond(event->connect.conn_handle, &bond_count);
                if (bonded_peer && registration_allowed) {
                    // The admin explicitly opened a 60s window to register a NEW phone.
                    // Without this, an already-bonded phone (e.g. the owner's own handset
                    // running a background auto-reconnect service) would win the single
                    // connection slot almost every time, since it reconnects far faster
                    // than a human can open a scanner and tap connect on a new device -
                    // making "Allow registration" look broken. Bounce the known phone; its
                    // own reconnect logic will simply retry once the window closes.
                    event_log_add("BLE registration: известный телефон отклонён на время окна регистрации");
                    ble_gap_terminate(event->connect.conn_handle, BLE_ERR_REM_USER_CONN_TERM);
                    return 0;
                }
                if (!bonded_peer && !registration_allowed) {
                    event_log_add("BLE security: новый телефон отклонён, регистрация закрыта");
                    ble_gap_terminate(event->connect.conn_handle, BLE_ERR_REM_USER_CONN_TERM);
                    return 0;
                }
                if (!bonded_peer && bond_count >= MAX_BONDED_PHONES) {
                    event_log_add("BLE security: лимит 10 bonds, удалите телефон через Web UI");
                    ble_gap_terminate(event->connect.conn_handle, BLE_ERR_REM_USER_CONN_TERM);
                    return 0;
                }
                // Не инициируем security проактивно здесь: на Android это создаёт
                // гонку с его собственным реактивным pairing, который стек телефона
                // сам запускает, как только GATT-клиент во время service discovery
                // натыкается на характеристику с флагом READ_ENC/WRITE_ENC
                // (CHR_ADMIN_AUTH, CHR_ADMIN_CONFIG). Два независимых инициатора
                // security на одном SMP-канале приводили к тому, что Android
                // показывал диалог подтверждения дважды и один раз сбрасывал
                // внутреннее состояние bonding (dm_reset_sec_dev_pending), прежде
                // чем шифрование всё же завершалось. Оставляем только реактивный
                // путь: телефон сам инициирует шифрование, когда попытается
                // прочитать/записать защищённую характеристику, и получит
                // BLE_ATT_ERR_INSUFFICIENT_AUTHEN от стека NimBLE.
                event_log_add("BLE security: ожидание запроса от телефона (%s)",
                              bonded_peer ? "известный bond" : "новый Pairing");
            } else {
                ble_phone_start_advertising();
            }
            return 0;
        case BLE_GAP_EVENT_DISCONNECT:
            event_log_add("BLE GATT: телефон отключён");
            portENTER_CRITICAL(&s_connection_lock);
            s_conn_handle = BLE_HS_CONN_HANDLE_NONE;
            s_admin_conn = BLE_HS_CONN_HANDLE_NONE;
            s_rssi_valid = false;
            s_encrypted = false;
            s_bonded = false;
            portEXIT_CRITICAL(&s_connection_lock);
            lock_control_report_disconnected();
            ble_phone_start_advertising();
            return 0;
        case BLE_GAP_EVENT_ENC_CHANGE: {
            struct ble_gap_conn_desc desc;
            if (event->enc_change.status == 0 &&
                ble_gap_conn_find(event->enc_change.conn_handle, &desc) == 0) {
                event_log_add("BLE security: encrypted=%u bonded=%u key=%u",
                              desc.sec_state.encrypted, desc.sec_state.bonded,
                              desc.sec_state.key_size);
                portENTER_CRITICAL(&s_connection_lock);
                s_encrypted = desc.sec_state.encrypted;
                s_bonded = desc.sec_state.bonded;
                portEXIT_CRITICAL(&s_connection_lock);
            } else {
                event_log_add("BLE security failed: %d", event->enc_change.status);
            }
            return 0;
        }
        case BLE_GAP_EVENT_REPEAT_PAIRING:
            event_log_add("BLE security: повторный Pairing отклонён; удалите bond через Web UI");
            return BLE_GAP_REPEAT_PAIRING_IGNORE;
        case BLE_GAP_EVENT_PASSKEY_ACTION:
            event_log_add("BLE security: ожидается IO action=%u",
                          event->passkey.params.action);
            return 0;
        case BLE_GAP_EVENT_ADV_COMPLETE:
            ble_phone_start_advertising();
            return 0;
        default:
            return 0;
    }
}

static void rssi_task(void *arg)
{
    (void)arg;
    for (;;) {
        uint16_t conn_handle;
        portENTER_CRITICAL(&s_connection_lock);
        conn_handle = s_conn_handle;
        portEXIT_CRITICAL(&s_connection_lock);
        if (conn_handle != BLE_HS_CONN_HANDLE_NONE) {
            struct ble_gap_conn_desc desc;
            int8_t rssi;
            if (ble_gap_conn_find(conn_handle, &desc) == 0 &&
                desc.sec_state.encrypted && desc.sec_state.bonded &&
                ble_gap_conn_rssi(conn_handle, &rssi) == 0) {
                portENTER_CRITICAL(&s_connection_lock);
                if (s_conn_handle == conn_handle) {
                    s_last_rssi = rssi;
                    s_rssi_valid = true;
                }
                portEXIT_CRITICAL(&s_connection_lock);
                app_config_t cfg;
                app_config_get(&cfg);
                // Hysteresis: getting the door open requires the strict threshold;
                // once it's open, only the weaker hold threshold is required to keep
                // it from starting the Timer A countdown. Using a single shared
                // threshold for both directions made RSSI noise right at the
                // boundary flip open/hold state rapidly (chatter/дребезг).
                //
                // While reopen_blocked (anti-flap guard after "long open"), the lock
                // is physically closed, so is_open() alone would wrongly select the
                // strict open threshold here. The 3-consecutive-weak-RSSI release
                // must be measured against the weaker hold threshold too, since that
                // is the "слабый порог" the block release is meant to react to.
                bool use_hold_threshold = lock_control_is_open() || lock_control_is_blocked();
                int8_t effective_threshold = use_hold_threshold
                    ? cfg.phone_rssi_hold_threshold
                    : cfg.phone_rssi_threshold;
                lock_control_report_rssi(rssi >= effective_threshold);
            }
        }
        vTaskDelay(pdMS_TO_TICKS(500));
    }
}

static esp_err_t ble_phone_gatt_init(void)
{
    ble_hs_cfg.sm_bonding = 1;
    ble_hs_cfg.sm_mitm = 0;
    ble_hs_cfg.sm_sc = 1;
    ble_hs_cfg.sm_sc_only = 0;
    ble_hs_cfg.sm_io_cap = BLE_SM_IO_CAP_NO_IO;
    ble_hs_cfg.sm_our_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    ble_hs_cfg.sm_their_key_dist = BLE_SM_PAIR_KEY_DIST_ENC | BLE_SM_PAIR_KEY_DIST_ID;
    ble_hs_cfg.store_status_cb = ble_store_util_status_rr;
    ble_store_config_init();

    ble_svc_gap_init();
    ble_svc_gatt_init();
    int rc = ble_svc_gap_device_name_set(BLE_PHONE_NAME);
    if (rc != 0) return ESP_FAIL;
    rc = ble_gatts_count_cfg(s_services);
    if (rc != 0) return ESP_FAIL;
    rc = ble_gatts_add_svcs(s_services);
    if (rc != 0) return ESP_FAIL;
    return xTaskCreate(rssi_task, "ble_phone_rssi", 3072, NULL, 5, NULL) == pdPASS
               ? ESP_OK : ESP_ERR_NO_MEM;
}

static esp_err_t ble_phone_start_advertising(void)
{
    portENTER_CRITICAL(&s_connection_lock);
    bool enabled = s_enabled;
    portEXIT_CRITICAL(&s_connection_lock);
    if (!enabled) return ESP_OK;

    int rc = ble_hs_id_infer_auto(0, &s_addr_type);
    if (rc != 0) return ESP_FAIL;

    struct ble_hs_adv_fields fields = {0};
    fields.flags = BLE_HS_ADV_F_DISC_GEN | BLE_HS_ADV_F_BREDR_UNSUP;
    fields.name = (uint8_t *)BLE_PHONE_NAME;
    fields.name_len = strlen(BLE_PHONE_NAME);
    fields.name_is_complete = 1;
    fields.uuids128 = (ble_uuid128_t *)&s_service_uuid;
    fields.num_uuids128 = 1;
    fields.uuids128_is_complete = 1;
    rc = ble_gap_adv_set_fields(&fields);
    if (rc != 0) return ESP_FAIL;

    struct ble_gap_adv_params params = {0};
    params.conn_mode = BLE_GAP_CONN_MODE_UND;
    params.disc_mode = BLE_GAP_DISC_MODE_GEN;
    rc = ble_gap_adv_start(s_addr_type, NULL, BLE_HS_FOREVER, &params,
                           advertising_event, NULL);
    if (rc == 0 || rc == BLE_HS_EALREADY) {
        event_log_add("BLE GATT advertising запущен");
        return ESP_OK;
    }
    event_log_add("BLE GATT advertising error: %d", rc);
    return ESP_FAIL;
}

static void on_sync(void)
{
    event_log_add("NimBLE phone-only host синхронизирован");
    if (ble_phone_start_advertising() != ESP_OK) {
        event_log_add("BLE phone advertising не запущен");
    }
}

static void host_task(void *arg)
{
    (void)arg;
    nimble_port_run();
    nimble_port_freertos_deinit();
}

esp_err_t ble_phone_init(void)
{
    esp_err_t err = nimble_port_init();
    if (err != ESP_OK) return err;
    err = ble_phone_gatt_init();
    if (err != ESP_OK) return err;
    ble_hs_cfg.sync_cb = on_sync;
    nimble_port_freertos_init(host_task);
    return ESP_OK;
}

esp_err_t ble_phone_set_enabled(bool enabled)
{
    uint16_t conn_handle;
    portENTER_CRITICAL(&s_connection_lock);
    s_enabled = enabled;
    conn_handle = s_conn_handle;
    portEXIT_CRITICAL(&s_connection_lock);

    if (!enabled) {
        ble_gap_adv_stop();
        if (conn_handle != BLE_HS_CONN_HANDLE_NONE) {
            ble_gap_terminate(conn_handle, BLE_ERR_REM_USER_CONN_TERM);
        }
        event_log_add("BLE временно остановлен для диагностики Wi-Fi");
        return ESP_OK;
    }

    event_log_add("BLE возобновлён после диагностики Wi-Fi");
    return ble_phone_start_advertising();
}

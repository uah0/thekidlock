package com.blelock.app

import android.content.Context
import android.os.Build

class LockSettings(context: Context) {
    private val storageContext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
        !context.isDeviceProtectedStorage) {
        context.createDeviceProtectedStorageContext()
    } else context
    private val preferences = storageContext.getSharedPreferences("ble_lock", Context.MODE_PRIVATE)

    init {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
            !preferences.contains(KEY_AUTO_OPEN) && !context.isDeviceProtectedStorage) {
            val oldPreferences = context.getSharedPreferences("ble_lock", Context.MODE_PRIVATE)
            if (oldPreferences.contains(KEY_AUTO_OPEN)) {
                preferences.edit()
                    .putBoolean(KEY_AUTO_OPEN, oldPreferences.getBoolean(KEY_AUTO_OPEN, false))
                    .commit()
            }
        }
    }

    var autoOpenEnabled: Boolean
        get() = preferences.getBoolean(KEY_AUTO_OPEN, false)
        set(value) {
            preferences.edit().putBoolean(KEY_AUTO_OPEN, value).commit()
        }

    companion object {
        private const val KEY_AUTO_OPEN = "auto_open_enabled"
    }
}

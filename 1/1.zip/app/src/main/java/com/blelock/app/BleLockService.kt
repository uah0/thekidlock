package com.blelock.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class BleLockService : Service(), BleRepository.Listener {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var repository: BleRepository
    private lateinit var settings: LockSettings
    private var openSentForPresence = false
    private var stopping = false
    private val departureRecovery = Runnable {
        if (!stopping && settings.autoOpenEnabled && openSentForPresence) {
            openSentForPresence = false
            repository.findAndConnect()
        }
    }

    override fun onCreate() {
        super.onCreate()
        settings = LockSettings(this)
        createNotificationChannel()
        startAsForeground(getString(R.string.service_starting))
        repository = BleRepository(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP || !settings.autoOpenEnabled) {
            stopSelfSafely()
            return START_NOT_STICKY
        }
        if (!hasPermissions()) {
            updateNotification(getString(R.string.service_permissions_missing))
            return START_NOT_STICKY
        }
        scheduleSearch(0)
        return START_STICKY
    }

    override fun onDestroy() {
        stopping = true
        handler.removeCallbacksAndMessages(null)
        repository.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onBleState(state: BleRepository.State, detail: String) {
        updateNotification(detail)
        when (state) {
            BleRepository.State.READY -> {
                if (!openSentForPresence) repository.openNow()
            }
            BleRepository.State.OPEN_SENT -> openSentForPresence = true
            BleRepository.State.IDLE, BleRepository.State.ERROR -> {
                if (stopping) return
                if (openSentForPresence) {
                    handler.postDelayed({
                        repository.waitForDeparture()
                        // If ESP32 was rebooted while the phone stayed nearby,
                        // the old GATT session may not report a clean disconnect.
                        // Do not wait forever for a departure: re-discover the
                        // advertising lock and establish a fresh secured link.
                        handler.removeCallbacks(departureRecovery)
                        handler.postDelayed(departureRecovery, DEPARTURE_RECOVERY_MS)
                    }, RECONNECT_DELAY_MS)
                } else {
                    scheduleSearch(RECONNECT_DELAY_MS)
                }
            }
            BleRepository.State.DEPARTED -> {
                handler.removeCallbacks(departureRecovery)
                openSentForPresence = false
                scheduleSearch(RECONNECT_DELAY_MS)
            }
            else -> Unit
        }
    }

    override fun onLockData(info: String?, status: String?) {
        if (info != null && status != null) {
            updateNotification("$info · $status")
        }
    }

    private fun scheduleSearch(delayMs: Long) {
        handler.removeCallbacks(searchRunnable)
        handler.postDelayed(searchRunnable, delayMs)
    }

    private val searchRunnable = Runnable {
        if (!stopping && settings.autoOpenEnabled) repository.findAndConnect()
    }

    private fun stopSelfSafely() {
        stopping = true
        handler.removeCallbacksAndMessages(null)
        if (::repository.isInitialized) repository.close()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startAsForeground(text: String) {
        val notification = buildNotification(text)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopService = PendingIntent.getService(
            this,
            1,
            Intent(this, BleLockService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle(getString(R.string.service_title))
            .setContentText(text)
            .setContentIntent(openApp)
            .setOngoing(true)
            .addAction(0, getString(R.string.stop_service), stopService)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.service_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun hasPermissions(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        }
        return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) ==
            PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    }

    companion object {
        const val ACTION_START = "com.blelock.app.action.START"
        const val ACTION_STOP = "com.blelock.app.action.STOP"
        private const val CHANNEL_ID = "ble_lock_service"
        private const val NOTIFICATION_ID = 1001
        private const val RECONNECT_DELAY_MS = 3_000L
        private const val DEPARTURE_RECOVERY_MS = 30_000L
    }
}

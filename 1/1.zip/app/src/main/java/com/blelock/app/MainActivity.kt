package com.blelock.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statusView: TextView
    private lateinit var permissionView: TextView
    private lateinit var autoOpenSwitch: Switch
    private lateinit var settings: LockSettings
    private lateinit var repository: BleRepository
    private lateinit var connectButton: Button
    private lateinit var openButton: Button
    private lateinit var lockDataView: TextView
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = LockSettings(this)
        repository = BleRepository(this, object : BleRepository.Listener {
            override fun onBleState(state: BleRepository.State, detail: String) {
                statusView.text = detail
                connectButton.isEnabled = state != BleRepository.State.SCANNING &&
                    state != BleRepository.State.CONNECTING && state != BleRepository.State.BONDING
                openButton.isEnabled = state == BleRepository.State.READY
                appendLog(detail)
            }

            override fun onLockData(info: String?, status: String?) {
                lockDataView.text = getString(
                    R.string.lock_data,
                    info ?: "—",
                    status ?: "—"
                )
            }

        })
        setContentView(createContent())
        refreshState()
    }

    override fun onResume() {
        super.onResume()
        refreshState()
    }

    override fun onDestroy() {
        repository.close()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_BLE_PERMISSIONS) {
            refreshState()
            if (settings.autoOpenEnabled && hasBlePermissions()) startAutoOpenService()
        }
    }

    private fun createContent(): ScrollView {
        val padding = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(padding, padding, padding, padding)
        }

        root.addView(TextView(this).apply {
            text = getString(R.string.app_title)
            textSize = 28f
        }, fullWidth())

        statusView = TextView(this).apply { textSize = 18f }
        permissionView = TextView(this).apply { textSize = 16f }
        root.addView(statusView, spacedFullWidth())
        root.addView(permissionView, spacedFullWidth())

        root.addView(Button(this).apply {
            text = getString(R.string.grant_permissions)
            setOnClickListener { requestMissingPermissions() }
        }, spacedFullWidth())

        autoOpenSwitch = Switch(this).apply {
            text = getString(R.string.auto_open)
            isChecked = settings.autoOpenEnabled
            setOnCheckedChangeListener { _, checked ->
                settings.autoOpenEnabled = checked
                if (checked && hasBlePermissions()) startAutoOpenService()
                else if (!checked) stopAutoOpenService()
                refreshState()
            }
        }
        root.addView(autoOpenSwitch, spacedFullWidth())

        root.addView(Button(this).apply {
            text = getString(R.string.disable_battery_optimization)
            setOnClickListener { requestIgnoreBatteryOptimizations() }
        }, spacedFullWidth())

        connectButton = Button(this).apply {
            text = getString(R.string.register_phone)
            setOnClickListener {
                // Manual registration must use the Activity connection only;
                // a running auto-open service would create a second SMP flow.
                stopAutoOpenService()
                if (hasBlePermissions()) {
                    Handler(Looper.getMainLooper()).postDelayed(
                        { repository.findAndConnect() }, 700L
                    )
                } else requestMissingPermissions()
            }
        }
        root.addView(connectButton, spacedFullWidth())
        openButton = Button(this).apply {
            text = getString(R.string.open_now)
            isEnabled = false
            setOnClickListener { repository.openNow() }
        }
        root.addView(openButton, spacedFullWidth())


        lockDataView = TextView(this).apply {
            text = getString(R.string.lock_data, "—", "—")
            textSize = 16f
        }
        root.addView(lockDataView, spacedFullWidth())

        logView = TextView(this).apply {
            text = getString(R.string.event_log_title)
            textSize = 14f
        }
        root.addView(logView, spacedFullWidth())

        root.addView(TextView(this).apply {
            text = getString(R.string.stage_a2_note)
            textSize = 15f
        }, spacedFullWidth())

        return ScrollView(this).apply { addView(root) }
    }

    private fun refreshState() {
        val adapter = getSystemService(BluetoothManager::class.java)?.adapter
        statusView.text = when {
            adapter == null -> getString(R.string.bluetooth_unavailable)
            !hasBlePermissions() -> getString(R.string.permissions_required)
            !adapter.isEnabled -> getString(R.string.bluetooth_disabled)
            else -> getString(R.string.ready_for_ble)
        }
        permissionView.text = getString(
            R.string.permission_status,
            if (hasBlePermissions()) getString(R.string.allowed) else getString(R.string.not_allowed)
        )
        autoOpenSwitch.isChecked = settings.autoOpenEnabled
    }

    private fun hasBlePermissions(): Boolean = requiredPermissions().all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestMissingPermissions() {
        val missing = requiredPermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), REQUEST_BLE_PERMISSIONS)
        } else if (settings.autoOpenEnabled) {
            startAutoOpenService()
        }
    }

    private fun startAutoOpenService() {
        val intent = Intent(this, BleLockService::class.java)
            .setAction(BleLockService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
    }

    private fun requestIgnoreBatteryOptimizations() {
        val powerManager = getSystemService(PowerManager::class.java)
        if (powerManager?.isIgnoringBatteryOptimizations(packageName) == true) return
        startActivity(Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:$packageName")
        ))
    }

    private fun stopAutoOpenService() {
        stopService(Intent(this, BleLockService::class.java))
    }

    private fun appendLog(message: String) {
        logView.append("\n$message")
    }


    private fun requiredPermissions(): List<String> {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions += Manifest.permission.BLUETOOTH_SCAN
            permissions += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            permissions += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        return permissions
    }

    private fun fullWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun spacedFullWidth() = fullWidth().apply {
        topMargin = (14 * resources.displayMetrics.density).toInt()
    }

    companion object {
        private const val REQUEST_BLE_PERMISSIONS = 100
    }
}

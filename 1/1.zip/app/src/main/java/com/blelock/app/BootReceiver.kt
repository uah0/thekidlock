package com.blelock.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val regularBoot = intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        val lockedBoot = Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
            intent.action == Intent.ACTION_LOCKED_BOOT_COMPLETED
        if (!regularBoot && !lockedBoot) return
        if (!LockSettings(context).autoOpenEnabled) {
            return
        }
        val service = Intent(context, BleLockService::class.java)
            .setAction(BleLockService.ACTION_START)
            .setPackage(context.packageName)
        // Start while the BOOT_COMPLETED receiver is alive. Delaying with a bare
        // Handler after onReceive returns allows Android to kill the process.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(service)
        } else {
            context.startService(service)
        }
    }
}

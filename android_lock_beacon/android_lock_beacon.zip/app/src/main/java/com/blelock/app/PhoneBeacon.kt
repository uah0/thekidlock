package com.blelock.app

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.content.Intent
import android.util.Log
import java.security.SecureRandom
import java.util.UUID

/** Discovery data is public. Only a bonded, encrypted GATT read confirms presence. */
class PhoneBeacon(private val context: Context) {
    companion object {
        private const val TAG = "PhoneBeacon"
        const val MANUFACTURER_ID = 0xF0E1 // Experimental identifier, not a Bluetooth SIG allocation.
        val SERVICE_UUID: UUID = UUID.fromString("6f4f0010-9a7b-4c21-8d32-5e6f708192a3")
        val PROOF_UUID: UUID = UUID.fromString("6f4f0011-9a7b-4c21-8d32-5e6f708192a3")
        val OWNER_STATUS_UUID: UUID = UUID.fromString("6f4f0012-9a7b-4c21-8d32-5e6f708192a3")
        val WIFI_SETUP_UUID: UUID = UUID.fromString("6f4f0013-9a7b-4c21-8d32-5e6f708192a3")
        val HOTSPOT_IP_UUID: UUID = BleProtocol.PHONE_HOTSPOT_IP_UUID
        val PROOF = "BLE_LOCK_V1".toByteArray(Charsets.US_ASCII)
        const val ACTION_OWNER_STATUS_CHANGED = "com.blelock.app.OWNER_STATUS_CHANGED"
        const val ACTION_WIFI_PROVISIONING_DISCONNECTED = "com.blelock.app.WIFI_PROVISIONING_DISCONNECTED"
    }

    private val bluetoothManager = context.getSystemService(BluetoothManager::class.java)
    private var server: BluetoothGattServer? = null
    private var advertiserCallback: AdvertiseCallback? = null
    private var wanted = false
    private var autoOpenWanted = false
    private var wifiProvisioningRequested = false
    private var provisioningCredentials: ByteArray? = null
    private var provisioningReadPeer: String? = null
    @Volatile private var hotspotIpBytes: ByteArray? = null
    private var sessionId = 0

    val isWifiProvisioningActive: Boolean get() = wifiProvisioningRequested

    private val serverCallback = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            if (newState != BluetoothGatt.STATE_DISCONNECTED || provisioningCredentials == null) return
            val peer = runCatching { device.address }.getOrNull()
            if (provisioningReadPeer == null || peer != provisioningReadPeer) {
                Log.i(TAG, "Ignoring disconnect before Wi-Fi credentials were read by this peer")
                return
            }
            provisioningCredentials = null
            provisioningReadPeer = null
            wifiProvisioningRequested = false
            if (autoOpenWanted) restartAdvertising() else stop()
            Log.i(TAG, "Wi-Fi provisioning read completed; returning to normal beacon mode")
            context.sendBroadcast(
                Intent(ACTION_WIFI_PROVISIONING_DISCONNECTED).setPackage(context.packageName)
            )
        }

        override fun onServiceAdded(status: Int, service: BluetoothGattService) {
            if (!wanted || service.uuid != SERVICE_UUID) return
            if (status == BluetoothGatt.GATT_SUCCESS) startAdvertising()
            else Log.e(TAG, "GATT service registration failed: $status")
        }

        override fun onCharacteristicReadRequest(
            device: BluetoothDevice, requestId: Int, offset: Int,
            characteristic: BluetoothGattCharacteristic
        ) {
            val current = server ?: return
            val bonded = try { device.bondState == BluetoothDevice.BOND_BONDED }
            catch (_: SecurityException) { false }
            val proofRead = wanted && bonded && characteristic.uuid == PROOF_UUID && offset <= PROOF.size
            val wifiValue = provisioningCredentials
            val wifiRead = wanted && bonded && wifiValue != null &&
                characteristic.uuid == WIFI_SETUP_UUID && offset <= wifiValue.size
            val hotspotIpValue = hotspotIpBytes ?: ByteArray(4)
            val hotspotIpRead = wanted && bonded && characteristic.uuid == HOTSPOT_IP_UUID &&
                offset <= hotspotIpValue.size
            val status = if (proofRead || wifiRead || hotspotIpRead) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE
            val bytes = when {
                proofRead -> PROOF
                wifiRead -> {
                    provisioningReadPeer = try { device.address }
                    catch (_: SecurityException) { null }
                    wifiValue!!
                }
                hotspotIpRead -> hotspotIpValue
                else -> null
            }
            val value = bytes?.copyOfRange(offset, bytes.size)
            try { current.sendResponse(device, requestId, status, offset, value) }
            catch (e: SecurityException) { Log.e(TAG, "GATT response denied", e) }
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray
        ) {
            val current = server ?: return
            val bonded = try { device.bondState == BluetoothDevice.BOND_BONDED }
            catch (_: SecurityException) { false }
            val valid = wanted && bonded && characteristic.uuid == OWNER_STATUS_UUID &&
                !preparedWrite && offset == 0 && value.size == 1 && (value[0] == 0.toByte() || value[0] == 1.toByte())
            if (valid) {
                LockSettings(context).ownerAccessConfirmed = value[0] == 1.toByte()
                context.sendBroadcast(
                    Intent(ACTION_OWNER_STATUS_CHANGED).setPackage(context.packageName)
                )
            }
            if (responseNeeded) {
                val status = if (valid) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE
                try { current.sendResponse(device, requestId, status, offset, null) }
                catch (e: SecurityException) { Log.e(TAG, "GATT owner status response denied", e) }
            }
        }
    }

    fun start() {
        autoOpenWanted = true
        if (wanted) {
            if (!isWifiProvisioningActive) restartAdvertising()
            return
        }
        startServer()
    }

    fun startWifiProvisioning(ssid: String, password: String, hotspotIp: ByteArray?) {
        val ssidBytes = ssid.toByteArray(Charsets.UTF_8)
        val passwordBytes = password.toByteArray(Charsets.UTF_8)
        require(ssidBytes.isNotEmpty() && ssidBytes.size <= 32) { "Invalid Wi-Fi SSID length" }
        require(passwordBytes.size <= 64) { "Invalid Wi-Fi password length" }
        wifiProvisioningRequested = true
        provisioningCredentials = byteArrayOf(ssidBytes.size.toByte(), passwordBytes.size.toByte()) +
            ssidBytes + passwordBytes
        provisioningReadPeer = null
        setHotspotIp(hotspotIp)
        if (!wanted) startServer() else restartAdvertising()
    }

    /** Suppress ordinary AUTO advertising while Android creates/resolves its hotspot. */
    fun prepareWifiProvisioning(resumeAutoOpen: Boolean) {
        autoOpenWanted = resumeAutoOpen
        wifiProvisioningRequested = true
        provisioningCredentials = null
        provisioningReadPeer = null
        setHotspotIp(null)
        val callback = advertiserCallback
        advertiserCallback = null
        try {
            if (callback != null) bluetoothManager.adapter?.bluetoothLeAdvertiser?.stopAdvertising(callback)
        } catch (e: Exception) { Log.w(TAG, "Could not pause AUTO beacon for Wi-Fi setup", e) }
        Log.i(TAG, "AUTO beacon paused while hotspot is being prepared")
    }

    fun cancelWifiProvisioning() {
        if (!wifiProvisioningRequested) return
        wifiProvisioningRequested = false
        provisioningCredentials = null
        provisioningReadPeer = null
        setHotspotIp(null)
        if (autoOpenWanted) {
            if (!wanted) startServer() else restartAdvertising()
        } else stop()
        Log.i(TAG, "Wi-Fi provisioning cancelled; beacon restored")
    }

    fun setHotspotIp(address: ByteArray?) {
        hotspotIpBytes = address?.takeIf { it.size == 4 && it.any { octet -> octet != 0.toByte() } }?.copyOf()
    }

    fun stopAutoOpen() {
        autoOpenWanted = false
        if (isWifiProvisioningActive) {
            if (provisioningCredentials != null) restartAdvertising()
            else {
                val callback = advertiserCallback
                advertiserCallback = null
                try {
                    if (callback != null) bluetoothManager.adapter?.bluetoothLeAdvertiser?.stopAdvertising(callback)
                } catch (e: Exception) { Log.w(TAG, "Could not pause provisioning beacon", e) }
            }
        } else stop()
    }

    private fun startServer() {
        if (wanted) return
        val adapter = bluetoothManager.adapter ?: return
        if (!adapter.isEnabled || adapter.bluetoothLeAdvertiser == null) return
        wanted = true
        sessionId = SecureRandom().nextInt()
        try {
            val characteristic = BluetoothGattCharacteristic(
                PROOF_UUID,
                BluetoothGattCharacteristic.PROPERTY_READ,
                BluetoothGattCharacteristic.PERMISSION_READ_ENCRYPTED
            )
            val service = BluetoothGattService(SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
            service.addCharacteristic(characteristic)
            service.addCharacteristic(
                BluetoothGattCharacteristic(
                    OWNER_STATUS_UUID,
                    BluetoothGattCharacteristic.PROPERTY_WRITE,
                    BluetoothGattCharacteristic.PERMISSION_WRITE_ENCRYPTED
                )
            )
            service.addCharacteristic(
                BluetoothGattCharacteristic(
                    WIFI_SETUP_UUID,
                    BluetoothGattCharacteristic.PROPERTY_READ,
                    BluetoothGattCharacteristic.PERMISSION_READ_ENCRYPTED
                )
            )
            service.addCharacteristic(
                BluetoothGattCharacteristic(
                    HOTSPOT_IP_UUID,
                    BluetoothGattCharacteristic.PROPERTY_READ,
                    BluetoothGattCharacteristic.PERMISSION_READ_ENCRYPTED
                )
            )
            server = bluetoothManager.openGattServer(context, serverCallback)
            if (server?.addService(service) != true) {
                Log.e(TAG, "GATT service could not be added")
                stop()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Phone beacon startup failed", e)
            stop()
        }
    }

    private fun startAdvertising() {
        if (!wanted || advertiserCallback != null) return
        val adapter = bluetoothManager.adapter ?: return
        val advertiser = adapter.bluetoothLeAdvertiser ?: return
        val id = context.getSharedPreferences("phone_beacon", Context.MODE_PRIVATE).let { prefs ->
            val old = prefs.getInt("device_id", 0)
            if (old != 0) old else SecureRandom().nextInt().let { fresh ->
                prefs.edit().putInt("device_id", fresh).apply()
                fresh
            }
        }
        val modeByte = if (provisioningCredentials != null) 0x81.toByte() else 1.toByte()
        val payload = byteArrayOf('L'.code.toByte(), 'O'.code.toByte(), 'C'.code.toByte(), 'K'.code.toByte(), modeByte) +
            intBytes(id) + intBytes(sessionId)
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(true).setTimeout(0).build()
        val data = AdvertiseData.Builder().addManufacturerData(MANUFACTURER_ID, payload)
            .setIncludeDeviceName(false).setIncludeTxPowerLevel(false).build()
        val callback = object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings) {
                Log.i(TAG, "Phone beacon active session=${sessionId.toUInt().toString(16)}")
            }
            override fun onStartFailure(errorCode: Int) {
                Log.e(TAG, "Phone beacon advertising failed: $errorCode")
                if (advertiserCallback === this) advertiserCallback = null
            }
        }
        advertiserCallback = callback
        try { advertiser.startAdvertising(settings, data, callback) }
        catch (e: Exception) {
            advertiserCallback = null
            Log.e(TAG, "Phone beacon advertising request failed", e)
        }
    }

    private fun restartAdvertising() {
        val callback = advertiserCallback
        advertiserCallback = null
        try {
            if (callback != null) bluetoothManager.adapter?.bluetoothLeAdvertiser?.stopAdvertising(callback)
        } catch (e: Exception) { Log.w(TAG, "Could not restart beacon advertising", e) }
        startAdvertising()
    }

    fun stop() {
        wanted = false
        autoOpenWanted = false
        wifiProvisioningRequested = false
        provisioningCredentials = null
        provisioningReadPeer = null
        hotspotIpBytes = null
        val callback = advertiserCallback
        advertiserCallback = null
        try {
            if (callback != null) bluetoothManager.adapter?.bluetoothLeAdvertiser?.stopAdvertising(callback)
            server?.clearServices()
            server?.close()
        } catch (e: Exception) { Log.w(TAG, "Phone beacon shutdown error", e) }
        server = null
    }

    private fun intBytes(value: Int) = byteArrayOf(
        (value ushr 24).toByte(), (value ushr 16).toByte(),
        (value ushr 8).toByte(), value.toByte()
    )
}

#include "app_config.h"

#include <string.h>
#include "driver/gpio.h"
#include "nvs.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

#define NVS_NS "blelock"
static const char *TAG = "app_config";

static app_config_t s_cfg;
static SemaphoreHandle_t s_config_mutex;

static void set_defaults(void)
{
    memset(&s_cfg, 0, sizeof(s_cfg));
    s_cfg.phone_rssi_threshold = APP_DEFAULT_PHONE_RSSI_THRESHOLD;
    s_cfg.ble_tx_power_dbm = APP_DEFAULT_BLE_TX_POWER_DBM;
    s_cfg.long_open_s = APP_DEFAULT_LONG_OPEN_S;
    s_cfg.timer_a_ms = APP_DEFAULT_TIMER_A_MS;
    s_cfg.timer_b_s = APP_DEFAULT_TIMER_B_S;
    s_cfg.zone_exit_grace_ms = APP_DEFAULT_ZONE_EXIT_GRACE_MS;
    s_cfg.configuration_mode = false;
}

static bool values_valid(int phone_rssi,
                         uint32_t long_open_s,
                         uint32_t timer_a_ms, uint32_t timer_b_s)
{
    return phone_rssi >= APP_RSSI_THRESHOLD_MIN &&
           phone_rssi <= APP_RSSI_THRESHOLD_MAX &&
           long_open_s >= APP_LONG_OPEN_S_MIN &&
           long_open_s <= APP_TIMER_S_MAX &&
           timer_a_ms <= APP_TIMER_A_MS_MAX &&
           timer_b_s <= APP_TIMER_B_S_MAX &&
           (timer_a_ms == 0 || (uint64_t)long_open_s * 1000ULL > timer_a_ms);
}

esp_err_t app_config_init(void)
{
    set_defaults();
    if (!s_config_mutex) s_config_mutex = xSemaphoreCreateMutex();
    if (!s_config_mutex) return ESP_ERR_NO_MEM;
    nvs_handle_t h;
    esp_err_t err = nvs_open(NVS_NS, NVS_READONLY, &h);
    if (err == ESP_ERR_NVS_NOT_FOUND) return ESP_OK;
    if (err != ESP_OK) return err;

    int8_t phone_rssi = s_cfg.phone_rssi_threshold;
    int8_t ble_tx_power_dbm = s_cfg.ble_tx_power_dbm;
    uint32_t long_open_s = s_cfg.long_open_s;
    uint32_t timer_a_ms = s_cfg.timer_a_ms;
    uint32_t timer_b_s = s_cfg.timer_b_s;
    uint32_t zone_exit_grace_ms = s_cfg.zone_exit_grace_ms;
    nvs_get_i8(h, "phone_rssi", &phone_rssi);
    nvs_get_i8(h, "ble_tx_power", &ble_tx_power_dbm);
    if (nvs_get_u32(h, "long_open_s", &long_open_s) == ESP_ERR_NVS_NOT_FOUND) {
        uint32_t legacy_ms = 0;
        if (nvs_get_u32(h, "long_open_ms", &legacy_ms) == ESP_OK && legacy_ms > 0) {
            long_open_s = (legacy_ms + 999U) / 1000U;
        }
    }
    nvs_get_u32(h, "timer_a_ms", &timer_a_ms);
    nvs_get_u32(h, "timer_b_s", &timer_b_s);
    nvs_get_u32(h, "zone_exit_ms", &zone_exit_grace_ms);
    nvs_close(h);

    if (values_valid(phone_rssi, long_open_s, timer_a_ms, timer_b_s)) {
        s_cfg.phone_rssi_threshold = phone_rssi;
        if (ble_tx_power_dbm >= APP_BLE_TX_POWER_MIN_DBM &&
            ble_tx_power_dbm <= APP_BLE_TX_POWER_MAX_DBM &&
            (ble_tx_power_dbm - APP_BLE_TX_POWER_MIN_DBM) % 3 == 0) {
            s_cfg.ble_tx_power_dbm = ble_tx_power_dbm;
        }
        s_cfg.long_open_s = long_open_s;
        s_cfg.timer_a_ms = timer_a_ms;
        s_cfg.timer_b_s = timer_b_s;
        if (zone_exit_grace_ms <= APP_ZONE_EXIT_GRACE_MS_MAX) {
            s_cfg.zone_exit_grace_ms = zone_exit_grace_ms;
        }
    }
    return ESP_OK;
}

void app_config_get(app_config_t *out)
{
    if (!out) return;
    if (s_config_mutex) xSemaphoreTake(s_config_mutex, portMAX_DELAY);
    *out = s_cfg;
    if (s_config_mutex) xSemaphoreGive(s_config_mutex);
}

static esp_err_t set_logic_locked(int phone_rssi,
                               uint32_t long_open_s,
                               uint32_t timer_a_ms, uint32_t timer_b_s)
{
    if (!values_valid(phone_rssi, long_open_s, timer_a_ms, timer_b_s)) {
        ESP_LOGE(TAG, "logic validation failed: zone=%d long_s=%lu A=%lu B=%lu",
                 phone_rssi,
                 (unsigned long)long_open_s, (unsigned long)timer_a_ms,
                 (unsigned long)timer_b_s);
        return ESP_ERR_INVALID_ARG;
    }

    nvs_handle_t h;
    esp_err_t err = nvs_open(NVS_NS, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;
    if (err == ESP_OK) err = nvs_set_i8(h, "phone_rssi", phone_rssi);
    if (err == ESP_OK) err = nvs_set_u32(h, "long_open_s", long_open_s);
    if (err == ESP_OK) err = nvs_set_u32(h, "timer_a_ms", timer_a_ms);
    if (err == ESP_OK) err = nvs_set_u32(h, "timer_b_s", timer_b_s);
    if (err == ESP_OK) {
        nvs_erase_key(h, "long_open_ms");
        nvs_erase_key(h, "lock_gpio");
        nvs_erase_key(h, "lock_open");
    }
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);

    if (err == ESP_OK) {
        s_cfg.phone_rssi_threshold = phone_rssi;
        s_cfg.long_open_s = long_open_s;
        s_cfg.timer_a_ms = timer_a_ms;
        s_cfg.timer_b_s = timer_b_s;
    }
    return err;
}

static esp_err_t set_power_locked(int power_dbm)
{
    if (power_dbm < APP_BLE_TX_POWER_MIN_DBM ||
        power_dbm > APP_BLE_TX_POWER_MAX_DBM ||
        (power_dbm - APP_BLE_TX_POWER_MIN_DBM) % 3 != 0) {
        ESP_LOGE(TAG, "BLE power validation failed: %d dBm", power_dbm);
        return ESP_ERR_INVALID_ARG;
    }
    nvs_handle_t h;
    esp_err_t err = nvs_open(NVS_NS, NVS_READWRITE, &h);
    if (err != ESP_OK) return err;
    err = nvs_set_i8(h, "ble_tx_power", (int8_t)power_dbm);
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);
    if (err == ESP_OK) s_cfg.ble_tx_power_dbm = (int8_t)power_dbm;
    return err;
}

esp_err_t app_config_set_logic(int phone_rssi,
                               uint32_t long_open_s, uint32_t timer_a_ms, uint32_t timer_b_s)
{
    if (!s_config_mutex) return ESP_ERR_INVALID_STATE;
    xSemaphoreTake(s_config_mutex, portMAX_DELAY);
    esp_err_t err = set_logic_locked(phone_rssi, long_open_s, timer_a_ms, timer_b_s);
    xSemaphoreGive(s_config_mutex);
    return err;
}
esp_err_t app_config_set_ble_tx_power(int power_dbm)
{
    if (!s_config_mutex) return ESP_ERR_INVALID_STATE;
    xSemaphoreTake(s_config_mutex, portMAX_DELAY);
    esp_err_t err = set_power_locked(power_dbm);
    xSemaphoreGive(s_config_mutex);
    return err;
}

esp_err_t app_config_set_zone_exit_grace_ms(uint32_t grace_ms)
{
    if (grace_ms > APP_ZONE_EXIT_GRACE_MS_MAX) return ESP_ERR_INVALID_ARG;
    if (!s_config_mutex) return ESP_ERR_INVALID_STATE;
    xSemaphoreTake(s_config_mutex, portMAX_DELAY);
    nvs_handle_t h = 0;
    esp_err_t err = nvs_open(NVS_NS, NVS_READWRITE, &h);
    if (err == ESP_OK) err = nvs_set_u32(h, "zone_exit_ms", grace_ms);
    if (err == ESP_OK) err = nvs_commit(h);
    if (h) nvs_close(h);
    if (err == ESP_OK) s_cfg.zone_exit_grace_ms = grace_ms;
    xSemaphoreGive(s_config_mutex);
    return err;
}
